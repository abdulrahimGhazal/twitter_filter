from distutils.core import setup

setup(
    name='twitter_filter',
    version='0.1dev',
    packages=['twitter_filter'],
    url='',
    license='Creative Commons Attribution-Noncommercial-Share Alike license',
    author='AbdulrahimGhazal',
    author_email='',
    long_description=open('README.txt').read(),
)
